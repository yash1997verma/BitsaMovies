Font usage: Personal use only, no commercial use allowed
Distributed by: Font Monger
Designed by: Chris Vile
https://www.chrisvile.com


You may not edit this font
You may not rename this font
You may not repackage, distribute, or sale this font
You may not use this font in multimedia, tv, applications, video games, or film.


For a font license visit:
https://www.fontmonger.com
https://www.chrisvile.com

